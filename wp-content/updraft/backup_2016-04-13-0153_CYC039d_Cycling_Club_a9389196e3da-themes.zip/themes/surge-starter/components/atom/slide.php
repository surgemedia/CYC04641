 <?php 
 	$vars['image'] = $vars[0];
    $vars['class'] = $vars[1];

  ?>
 <div class="item <?php echo $vars['class']; ?>">
                    <img alt="" src="<?php echo $vars['image']; ?>"></img>
                </div>