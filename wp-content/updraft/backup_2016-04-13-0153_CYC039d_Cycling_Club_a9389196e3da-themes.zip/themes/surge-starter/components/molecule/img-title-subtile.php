<?php 
	 $vars['id'] = $vars[0];
	 $vars['class'] = $vars[1];
	 $vars['title'] = $vars[2];
	 $vars['blurb'] = $vars[3];
 ?>
<div class="col-md-4 img-title-subtitle text-center" style="background-image:url(https://unsplash.it/500/500)">
        <h1>
            <?php echo  $vars['title']; ?>
        </h1>
        <a class="view" href="">
            View Profile
        </a>
    </div>